export enum QuestionType{
  MULTIPLECHOICE= 'MULTIPLECHOICE',
  TEXT = 'TEXT',

}
