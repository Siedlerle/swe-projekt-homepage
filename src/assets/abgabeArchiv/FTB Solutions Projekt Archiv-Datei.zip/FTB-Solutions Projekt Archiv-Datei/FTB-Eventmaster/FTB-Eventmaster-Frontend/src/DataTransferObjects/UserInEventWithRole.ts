export interface UserInEventWithRole {
  id?: number;
  hasAttended: boolean;
}
