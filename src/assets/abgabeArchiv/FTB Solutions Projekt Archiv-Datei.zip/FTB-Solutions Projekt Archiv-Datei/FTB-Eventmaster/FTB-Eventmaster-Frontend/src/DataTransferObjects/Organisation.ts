export interface Organisation {
  id?: number;
  name: string;
  location: string;
  image?: string;
}
