import {EnumEventRole} from "./EnumEventRole";

export interface EventRole {
  id? : number;
  role?: EnumEventRole;
}
