export interface CustomDocument
{
  id: number;
  name: string;
  size: number;
  downloadUri: string;
}
