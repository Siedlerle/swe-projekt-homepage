export interface OrgaRole {
  id?: number;
  role: string;
}
