export interface EventSeries {
  id?: number;
  daysBetweenEvents?: number;
  amount?: number;
}
