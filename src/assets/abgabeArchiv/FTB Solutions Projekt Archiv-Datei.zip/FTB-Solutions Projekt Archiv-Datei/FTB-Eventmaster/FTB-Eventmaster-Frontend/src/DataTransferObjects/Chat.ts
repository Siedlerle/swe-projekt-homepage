export interface Chat{
  id? : number;
  message : string;
}
