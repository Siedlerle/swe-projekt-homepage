# SysAdminConsole

Die System-Admin Anwendung zum erstellen von Organisationen und zum hinzufügen von Organisations Admins

zum Ausführen der Anwendung in die Konsole eingeben: java -jar SysAdmin-Console-Application.jar

