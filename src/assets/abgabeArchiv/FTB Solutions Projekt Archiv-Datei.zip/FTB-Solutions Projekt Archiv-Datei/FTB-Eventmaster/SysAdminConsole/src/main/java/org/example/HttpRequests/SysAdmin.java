package org.example.HttpRequests;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.entities.Organisation;
import org.example.entities.User;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.Arrays;
import java.util.List;


public class SysAdmin {
    //private static final String url = "http://localhost:8080/sys-admin";
    private static final String url = "http://ftb-eventmaster.de:8080/sys-admin";
    private static final String password = "CooleresPasswort";

    public static String createOrganisation(Organisation organisation) throws IOException, InterruptedException, URISyntaxException {
        URI uri = new URI(url + "/organisation/create/" + password);
        HttpClient client = HttpClient.newBuilder().build();
        HttpRequest request = buildRequest(uri, createJsonForObject(organisation));
        return client.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    public static String changeOrganisation(Organisation organisation) throws IOException, InterruptedException, URISyntaxException {
        URI uri = new URI(url + "/organisation/change/" + password);
        HttpClient client = HttpClient.newBuilder().build();
        HttpRequest request = buildRequest(uri, createJsonForObject(organisation));
        return client.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    public static String deleteOrganisation(long organisationId) throws URISyntaxException, IOException, InterruptedException {
        URI uri = new URI(url + "/organisation/delete/" + organisationId + "/" + password);
        HttpClient client = HttpClient.newBuilder().build();
        HttpRequest request = buildRequest(uri, "");
        return client.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    public static String deleteUser(String emailAdress) throws URISyntaxException, IOException, InterruptedException {
        URI uri = new URI(url + "/user/delete/" + emailAdress + "/" + password);
        HttpClient client = HttpClient.newBuilder().build();
        HttpRequest request = buildRequest(uri, "");
        return client.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    public static String addUser(User user) throws URISyntaxException, IOException, InterruptedException {
        URI uri = new URI(url + "/user/add/" + password);
        HttpClient client = HttpClient.newBuilder().build();
        HttpRequest request = buildRequest(uri, createJsonForObject(user));
        return client.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }

    public static String addAdminToOrganisation(String emailAdress, long organisationId) throws URISyntaxException, IOException, InterruptedException {
        URI uri = new URI(url + "/admin/add/" + organisationId + "/" + emailAdress + "/" + password);
        HttpClient client = HttpClient.newBuilder().build();
        HttpRequest request = buildRequest(uri, "");
        return client.send(request, HttpResponse.BodyHandlers.ofString()).body();
    }
    public static List<Organisation> getAllOrganisations() throws URISyntaxException, IOException, InterruptedException {
        URI uri = new URI(url + "/orga/get-all/" + password);
        HttpClient client = HttpClient.newBuilder().build();
        HttpRequest request = buildRequest(uri, "");
        String body = client.send(request, HttpResponse.BodyHandlers.ofString()).body();
        return createOrganisationFromJson(body);
    }

    private static String createJsonForObject(Object object) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(object);
    }

    private static HttpRequest buildRequest(URI uri, String body) {
        return HttpRequest.newBuilder()
                .POST(HttpRequest.BodyPublishers.ofString(body))
                .uri(uri)
                .header("content-type", "application/json")
                .build();
    }
    private static List<Organisation> createOrganisationFromJson(String json) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return Arrays.asList(mapper.readValue(json, Organisation[].class));
    }
}
