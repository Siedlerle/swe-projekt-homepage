package org.example;

import org.example.HttpRequests.SysAdmin;
import org.example.entities.Organisation;
import org.example.entities.User;

import java.io.IOException;
import java.net.URISyntaxException;

import java.util.Scanner;


public class Main {
    public static void main(String[] args) throws URISyntaxException, IOException, InterruptedException {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("System Admin Application for FTB-Eventmaster");
        String input;
        do {
            System.out.println("\n\nWhat do you want to do?");
            System.out.println("""
                    0: Create Organisaton
                    1: Change Organistion
                    2: Delete Organisation
                    3: Add User
                    4: Delete User
                    5: Set Admin in Organistion
                    n: Close the application""");
            input = keyboard.nextLine();
            switch (input) {
                case "0" -> createOrganisation(keyboard);
                case "1" -> changeOrganisation(keyboard);
                case "2" -> deleteOrganisation(keyboard);
                case "3" -> addUser(keyboard);
                case "4" -> deleteUser(keyboard);
                case "5" -> setAdminInOrganisation(keyboard);
                default -> {
                }
            }
        } while (!input.equals("n"));
    }

    private static void createOrganisation(Scanner keyboard) throws IOException, URISyntaxException, InterruptedException {
        Organisation orga = new Organisation();

        System.out.println("Please enter a name for the Organisation, or enter 'c' to cancel:");
        String input = keyboard.nextLine();
        if (input.equals("c")) return;
        orga.setName(input);

        System.out.println("Please enter a location for the Organisation, or enter 'c' to cancel:");
        input = keyboard.nextLine();
        if (input.equals("c")) return;
        orga.setLocation(input);

        System.out.println(SysAdmin.createOrganisation(orga));
    }

    private static void changeOrganisation(Scanner keyboard) throws URISyntaxException, IOException, InterruptedException {
        printAllOrgas();
        Organisation organisation = new Organisation();

        System.out.println("Please enter the id of the Organisation you wish to change, or enter 'c' to cancel:");
        String input = keyboard.nextLine();
        if (input.equals("c")) return;
        int orgaId;
        try {
            orgaId = Integer.parseInt(input);
        }catch (Exception e){
            System.out.println("Please enter a number.");
            return;
        }
        organisation.setId(orgaId);

        System.out.println("Please enter the new name for the Organisation, or enter 'c' to cancel:");
        input = keyboard.nextLine();
        if (input.equals("c")) return;
        organisation.setName(input);

        System.out.println("Please enter the new location for the Organisation, or enter 'c' to cancel:");
        input = keyboard.nextLine();
        if (input.equals("c")) return;
        organisation.setLocation(input);

        System.out.println(SysAdmin.changeOrganisation(organisation));
    }

    private static void deleteOrganisation(Scanner keyboard) throws URISyntaxException, IOException, InterruptedException {
        printAllOrgas();

        System.out.println("Please enter the id of the orga you want to delete, or enter 'c' to cancel:");
        String input = keyboard.nextLine();
        if (input.equals("c")) return;
        int orgaId;
        try {
            orgaId = Integer.parseInt(input);
        }catch (Exception e){
            System.out.println("Please enter a number.");
            return;
        }
        System.out.println(SysAdmin.deleteOrganisation(orgaId));
    }

    private static void addUser(Scanner keyboard) throws URISyntaxException, IOException, InterruptedException {
        User user = new User();

        System.out.println("Please enter the firstname of the User you wish to create, or enter 'c' to cancel:");
        String input = keyboard.nextLine();
        if (input.equals("c")) return;
        user.setFirstname(input);

        System.out.println("Please enter the lastname of the User you wish to create, or enter 'c' to cancel:");
        input = keyboard.nextLine();
        if (input.equals("c")) return;
        user.setLastname(input);

        System.out.println("Please enter the email-Adress of the User you wish to create, or enter 'c' to cancel:");
        input = keyboard.nextLine();
        if (input.equals("c")) return;
        user.setEmailAdress(input)
        ;
        System.out.println("Please enter the password of the User you wish to create, or enter 'c' to cancel:");
        input = keyboard.nextLine();
        if (input.equals("c")) return;
        user.setPassword(input);

        user.setEnabled(true);
        System.out.println(SysAdmin.addUser(user));
    }

    private static void deleteUser(Scanner keyboard) throws URISyntaxException, IOException, InterruptedException {
        System.out.println("Please enter the emailAdress of the User you wish to delete, or enter 'c' to cancel:");
        String input = keyboard.nextLine();
        if (input.equals("c")) return;
        System.out.println(SysAdmin.deleteUser(input));
    }

    private static void setAdminInOrganisation(Scanner keyboard) throws URISyntaxException, IOException, InterruptedException {
        printAllOrgas();
        System.out.println("Please enter the orgaId where you want to add an admin, or enter 'c' to cancel:");
        String input = keyboard.nextLine();
        if (input.equals("c")) return;
        int orgaId;
        try {
            orgaId = Integer.parseInt(input);
        }catch (Exception e){
            System.out.println("Please enter a number.");
            return;
        }
        System.out.println("Please enter the emailAdress of the User you wish to make an admin, or enter 'c' to cancel:");
        String email = keyboard.nextLine();
        if (email.equals("c")) return;
        System.out.println(SysAdmin.addAdminToOrganisation(email,orgaId));
    }

    private static void printAllOrgas() throws URISyntaxException, IOException, InterruptedException {
        System.out.println("List of all Organisations:\n" +
                "id :name : location");
        SysAdmin.getAllOrganisations().
                forEach(organisation ->
                        System.out.println(organisation.getId() + "\t: " + organisation.getName() + "\t : " + organisation.getLocation()));
    }
}