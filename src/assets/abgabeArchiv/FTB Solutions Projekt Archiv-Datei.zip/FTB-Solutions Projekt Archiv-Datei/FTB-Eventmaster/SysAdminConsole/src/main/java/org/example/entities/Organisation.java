package org.example.entities;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class Organisation {
    private long id;
    private String name;
    private String location;
    @JsonIgnore
    private String image;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Organisation(){}

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
