package com.eventmaster.backend;

import com.eventmaster.backend.ControllerTests.AdminControllerTest;
import com.eventmaster.backend.ControllerTests.OrganizerControllerTest;
import com.eventmaster.backend.ControllerTests.SystemAdminControllerTest;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;



@SpringBootTest
class SweBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
