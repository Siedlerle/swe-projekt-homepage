package com.eventmaster.backend.entities;

public enum Role {
    USER,
    ADMIN
}
