package com.eventmaster.backend.security.Token;

public enum TokenType {
    BEARER
}
