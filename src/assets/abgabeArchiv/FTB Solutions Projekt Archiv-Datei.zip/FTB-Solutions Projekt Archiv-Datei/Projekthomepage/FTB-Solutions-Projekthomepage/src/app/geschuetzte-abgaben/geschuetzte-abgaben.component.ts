import { Component } from '@angular/core';

@Component({
  selector: 'app-geschuetzte-abgaben',
  templateUrl: './geschuetzte-abgaben.component.html',
  styleUrls: ['./geschuetzte-abgaben.component.css']
})
export class GeschuetzteAbgabenComponent {

}
