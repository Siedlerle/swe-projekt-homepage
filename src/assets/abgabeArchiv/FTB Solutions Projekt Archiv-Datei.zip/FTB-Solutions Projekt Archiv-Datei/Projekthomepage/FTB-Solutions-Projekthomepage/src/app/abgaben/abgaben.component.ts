import { Component } from '@angular/core';


@Component({
  selector: 'app-abgaben',
  templateUrl: './abgaben.component.html',
  styleUrls: ['./abgaben.component.css']
})

export class AbgabenComponent {
  
}
