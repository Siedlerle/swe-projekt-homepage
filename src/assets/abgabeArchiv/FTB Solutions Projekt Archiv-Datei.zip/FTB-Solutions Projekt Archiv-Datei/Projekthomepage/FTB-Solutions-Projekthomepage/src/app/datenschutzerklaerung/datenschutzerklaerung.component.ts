import { Component } from '@angular/core';

@Component({
  selector: 'app-datenschutzerklaerung',
  templateUrl: './datenschutzerklaerung.component.html',
  styleUrls: ['./datenschutzerklaerung.component.css']
})
export class DatenschutzerklaerungComponent {

}
