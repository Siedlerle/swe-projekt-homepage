import { Component } from '@angular/core';


@Component({
  selector: 'app-impressumn',
  templateUrl: './impressum.component.html',
  styleUrls: ['./impressum.component.css']
})
export class ImpressumComponent {

}
